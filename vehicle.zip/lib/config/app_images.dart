class AppImages {
  static const loginHeaderImage = 'assets/image.jpg';
}
