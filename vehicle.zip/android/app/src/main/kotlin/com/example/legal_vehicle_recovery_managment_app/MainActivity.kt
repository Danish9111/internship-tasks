package com.example.legal_vehicle_recovery_managment_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
